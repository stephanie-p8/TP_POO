package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import View.*;
import Model.*;

public class Controller implements ActionListener{

	Deck d;
	PanelDisplayCard panelDisplay;
	PanelForm form;
	PanelUpdateCard panelUpdate;
	PanelFormSearch panelSearch;
	
	
	public Controller(Deck d,PanelDisplayCard panelDisplay,PanelForm form,PanelUpdateCard panelUpdate,PanelFormSearch panelSearch) {
		this.d=d;
		this.panelDisplay=panelDisplay;
		this.form=form;
		this.panelUpdate=panelUpdate;
		this.panelSearch=panelSearch;
	}
	
	@Override
	public void actionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		
	}

}
